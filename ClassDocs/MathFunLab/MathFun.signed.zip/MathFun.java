/** 
 * 
 * @author Ammar Husain
 * Period 4
 *
 */
public class MathFun {
	/** 
	 * Method to the calculations and print the answers
	 */
	public void calculate()
	{
		int o1 = 4 + 9 ;
		System.out.println("4 + 9 = " + o1);
		int o2 = 46 / 7;
		System.out.println("46 / 7 = " + o2);
		int o3 = 46 % 7;
		System.out.println("46 % 7 = " + o3);
		double o4 = 2 * 3.0;
		System.out.println("2 * 3.0 = " + o4);
		double o5= (double)25 / 4;
		System.out.println("(double)25 / 4 = " + o5);
		int o6= (int)7.75 + 2;
		System.out.println("(int)7.75 + 2 = " + o6);
		int o7= (int)'P';
		System.out.println("(int)\'P\' = " + o7);
		char o8= (char)105;
		System.out.println("(char)105 = " + o8);
	}
}
