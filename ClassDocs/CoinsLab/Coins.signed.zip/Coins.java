/**
 * 
 * @author Ammar Husain
 * period  4
 */
public class Coins {
	// declare a private instance variable called cents
	// your code goes here
private int cents;


	/**
	 * constructor to initialize the instance variables
	 * @param money - amount for which the change is to
	 * 			be computed
	 */
	public Coins(int money)
	{
		//initialize cents
		// your code goes here
cents = money;
	}
	/**
	 * method to calculate the change
	 * @param money the amount for which the change is 
	 * 			to be computed
	 */
	public void change()
	{
		int runningTotal = cents;
		int quarters = runningTotal/25;
		runningTotal = runningTotal%25;
		int dimes = runningTotal/10;
		runningTotal = runningTotal%10;
		int nickels = runningTotal/5;
		runningTotal = runningTotal%5;
		int pennies = runningTotal/1;		
		System.out.println(cents + " cents =>"); 		
		System.out.println("Quarter(s) " + quarters);
		System.out.println("Dime(s) " + dimes);
		System.out.println("Nickel(s) " + nickels);
		System.out.println("Penny(s) " + pennies);	
	}

}
